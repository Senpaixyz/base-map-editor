import React, { useContext } from 'react';
import './App.css';
import CanvasMap from './components/CanvasMap';
import Controllers from './components/Controllers';
import ImageUpload from './components/ImageUpload';

import { SpriteProvider, SpriteContext } from './contexts/SpriteContext';
import { useShortcutKeys } from './utils/shortcutKeys';


const App = () => {
  return (
    <SpriteProvider>
      <div className="App">
        <ImageUpload />
        <div className="canvas-container">
          <CanvasMap />
          <Controllers />
        </div>
        <ShortcutKeysHandler />
      </div>
    </SpriteProvider>
  );
};

const ShortcutKeysHandler = () => {
  const {
    handleResizeSprite,
    handleChangeOrder,
    handleRotateSprite,
    handleFlipSprite,
    handleDeselectSprite,
  } = useContext(SpriteContext);

  useShortcutKeys({
    handleResizeSprite,
    handleChangeOrder,
    handleRotateSprite,
    handleFlipSprite,
    handleDeselectSprite,
  });

  return null;
};

export default App;
