import React, { useContext, useRef } from 'react';
import { Button, Input, Box, VStack, Text, Tooltip, IconButton } from '@chakra-ui/react';
import { SpriteContext } from '../contexts/SpriteContext';
import { FaSave, FaUpload, FaPlus, FaMinus, FaArrowUp, FaArrowDown, FaArrowsAltH, FaArrowsAltV, FaTimes, FaInfoCircle, FaTrash } from 'react-icons/fa';
import { LuImagePlus } from "react-icons/lu";
import ImageUpload from './ImageUpload';

const Controllers = () => {
    const {
        mapWidth,
        sprites,
        setSprites,
        handleAddSprite,
        spriteInputRef,
        handleSpriteUpload,
        selectedSprite,
        handleResizeSprite,
        handleDeselectSprite,
        handleChangeOrder,
        handleFlipSprite,
    } = useContext(SpriteContext);

    const fileInputRef = useRef(null);

    const handleSave = () => {
        const spriteData = sprites.map(sprite => ({
            id: sprite.id,
            name: sprite.name,
            src: sprite.src,  // Use the image URL directly
            x: sprite.x,
            y: sprite.y,
            width: sprite.width,
            height: sprite.height,
            flipH: sprite.flipH,
            flipV: sprite.flipV,
        }));

        const json = JSON.stringify(spriteData, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'sprites.json';
        a.click();
        URL.revokeObjectURL(url);
    };

    const handleLoad = (e) => {
        const file = e.target.files[0];
        if (file && file.type === 'application/json') {
            const reader = new FileReader();
            reader.onload = (event) => {
                const spriteData = JSON.parse(event.target.result);
                const loadedSprites = spriteData.map(sprite => {
                    const img = new Image();
                    img.src = sprite.src;  // Use the image URL directly
                    return new Promise(resolve => {
                        img.onload = () => resolve({
                            ...sprite,
                            img: img,
                        });
                    });
                });
                Promise.all(loadedSprites).then(setSprites);
            };
            reader.readAsText(file);
        }
    };

    const handleDeleteSprite = () => {
        if (selectedSprite !== null) {
            setSprites(sprites.filter((_, index) => index !== selectedSprite));
            handleDeselectSprite();
        }
    };

    return (
        <VStack align="start" spacing={4} className="controllers">
            {mapWidth && (
                <>
                    <Tooltip label="Save" aria-label="Save tooltip">
                        <IconButton
                            icon={<FaSave />}
                            colorScheme="teal"
                            onClick={handleSave}
                            isDisabled={sprites.length === 0 || selectedSprite !== null}
                        />
                    </Tooltip>
                    {sprites.length === 0 && (
                        <>
                            <Tooltip label="Load" aria-label="Load tooltip">
                                <IconButton
                                    icon={<FaUpload />}
                                    colorScheme="teal"
                                    onClick={() => fileInputRef.current.click()}
                                />
                            </Tooltip>
                            <Input
                                type="file"
                                ref={fileInputRef}
                                accept=".json"
                                onChange={handleLoad}
                                display="none"
                            />
                        </>
                    )}
                    <Tooltip label="Add Sprite" aria-label="Add Sprite tooltip">
                        <IconButton
                            icon={<LuImagePlus />}
                            colorScheme="teal"
                            onClick={handleAddSprite}
                        />
                    </Tooltip>
                    <Input
                        type="file"
                        ref={spriteInputRef}
                        accept=".png, .svg"
                        onChange={handleSpriteUpload}
                        display="none"
                    />
                    <ImageUpload />
                </>
            )}
            {selectedSprite !== null && (
                <>
                    <br />
                    <br />
                    <b>______</b>
                    <Tooltip label="Resize (+)" aria-label="Resize (+) tooltip">
                        <IconButton
                            icon={<FaPlus />}
                            colorScheme="teal"
                            onClick={() => handleResizeSprite('increase')}
                        />
                    </Tooltip>
                    <Tooltip label="Resize (-)" aria-label="Resize (-) tooltip">
                        <IconButton
                            icon={<FaMinus />}
                            colorScheme="teal"
                            onClick={() => handleResizeSprite('decrease')}
                        />
                    </Tooltip>
                    <Tooltip label="Bring Front" aria-label="Bring Front tooltip">
                        <IconButton
                            icon={<FaArrowUp />}
                            colorScheme="teal"
                            onClick={() => handleChangeOrder('front')}
                        />
                    </Tooltip>
                    <Tooltip label="Bring Back" aria-label="Bring Back tooltip">
                        <IconButton
                            icon={<FaArrowDown />}
                            colorScheme="teal"
                            onClick={() => handleChangeOrder('back')}
                        />
                    </Tooltip>
                    <Tooltip label="Flip Horizontal" aria-label="Flip Horizontal tooltip">
                        <IconButton
                            icon={<FaArrowsAltH />}
                            colorScheme="teal"
                            onClick={() => handleFlipSprite('horizontal')}
                        />
                    </Tooltip>
                    <Tooltip label="Flip Vertical" aria-label="Flip Vertical tooltip">
                        <IconButton
                            icon={<FaArrowsAltV />}
                            colorScheme="teal"
                            onClick={() => handleFlipSprite('vertical')}
                        />
                    </Tooltip>
                    <Tooltip label="Delete Sprite" aria-label="Delete Sprite tooltip">
                        <IconButton
                            icon={<FaTrash />}
                            colorScheme="red"
                            onClick={handleDeleteSprite}
                        />
                    </Tooltip>
                    <Tooltip label="Cancel" aria-label="Cancel tooltip">
                        <IconButton
                            icon={<FaTimes />}
                            colorScheme="red"
                            onClick={handleDeselectSprite}
                        />
                    </Tooltip>
                    <Tooltip
                        label={
                            <Box>
                                <Text fontSize="sm">
                                    <p>Shortcut Keys:</p>
                                    <ul>
                                        <li>Resize (+): + or Mouse Wheel forward</li>
                                        <li>Resize (-): - or Mouse Wheel backward</li>
                                        <li>Bring Front: Arrow Up</li>
                                        <li>Bring Back: Arrow Down</li>
                                        <li>Flip Horizontal: H</li>
                                        <li>Flip Vertical: V</li>
                                        <li>Cancel: Right Click</li>
                                    </ul>
                                </Text>
                            </Box>
                        }
                        aria-label="Shortcut keys tooltip"
                        hasArrow
                        placement="right"
                    >
                        <IconButton
                            icon={<FaInfoCircle />}
                            colorScheme="blue"
                            aria-label="Info"
                        />
                    </Tooltip>
                </>
            )}
        </VStack>
    );
};

export default Controllers;
