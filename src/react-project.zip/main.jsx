import React from 'react';
import ReactDOM from 'react-dom';
import { ChakraProvider } from '@chakra-ui/react';
import App from './App';
import { SpriteProvider } from './contexts/SpriteContext';

ReactDOM.render(
  <ChakraProvider>
    <SpriteProvider>
      <App />
    </SpriteProvider>
  </ChakraProvider>,
  document.getElementById('root')
);
